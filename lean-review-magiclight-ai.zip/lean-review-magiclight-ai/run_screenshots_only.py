#!/usr/bin/env python3
"""
Run this on your local machine (needs open internet).
Captures real magiclight.ai screenshots for all 17 scenes.
No TTS / no OpenRouter key needed.

Requirements:
  pip install playwright
  playwright install chromium

Usage:
  python3 run_screenshots_only.py
"""
import json, os, sys, subprocess, time

SPEC = "capture_spec.json"
MANIFEST = "capture_manifest.json"

def main():
    if not os.path.exists(SPEC):
        print("ERROR: capture_spec.json not found. Run this from the lean-review-magiclight-ai/ directory.")
        sys.exit(1)

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("Installing playwright...")
        subprocess.run([sys.executable, "-m", "pip", "install", "playwright"], check=True)
        subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=True)
        from playwright.sync_api import sync_playwright

    with open(SPEC) as f:
        spec = json.load(f)

    vp = spec.get("viewport", {"width": 1920, "height": 1080})
    os.makedirs("screenshots/scene", exist_ok=True)
    os.makedirs("screenshots/product", exist_ok=True)
    os.makedirs("broll", exist_ok=True)

    manifest = {"captures": [], "failed": []}

    OVERLAY_SELECTORS = [
        "[class*='cookie']", "[id*='cookie']", "[class*='consent']",
        "[class*='popup']", "[class*='modal']", "[class*='banner']",
        "button[class*='accept']", "button[class*='close']",
    ]

    def run_steps(page, steps):
        for step in steps:
            action = step.get("do")
            if action == "wait":
                time.sleep(step.get("ms", 1000) / 1000)
            elif action == "scroll":
                if "selector" in step:
                    page.locator(step["selector"]).scroll_into_view_if_needed()
                else:
                    page.evaluate(f"window.scrollBy(0, {step.get('pixels', 0)})")
                time.sleep(0.5)
            elif action == "dismiss_overlay":
                for sel in OVERLAY_SELECTORS:
                    try:
                        el = page.locator(sel).first
                        if el.is_visible(timeout=1000):
                            el.click(timeout=2000)
                            time.sleep(0.3)
                            break
                    except Exception:
                        continue
            elif action == "click":
                try:
                    page.locator(step["selector"]).first.click(timeout=5000)
                except Exception:
                    pass
            elif action == "hover":
                try:
                    page.locator(step["selector"]).first.hover(timeout=5000)
                except Exception:
                    pass
            elif action == "highlight":
                sel = step.get("selector", "body")
                try:
                    page.evaluate(f"""
                        (function() {{
                            var el = document.querySelector({json.dumps(sel)});
                            if (el) {{
                                el.style.outline = '4px solid #FF5F4C';
                                el.style.boxShadow = '0 0 12px rgba(255,95,76,0.6)';
                            }}
                        }})();
                    """)
                    time.sleep(step.get("ms", 800) / 1000)
                except Exception:
                    pass
            elif action == "key":
                page.keyboard.press(step.get("combo", "Escape"))
            elif action == "goto":
                page.goto(step["url"], timeout=30000, wait_until="domcontentloaded")
                time.sleep(1)

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        context = browser.new_context(
            viewport={"width": vp["width"], "height": vp["height"]},
            ignore_https_errors=True,
        )
        page = context.new_page()

        print(f"\nCapturing {len(spec['entries'])} screenshots from magiclight.ai...\n")

        for entry in spec["entries"]:
            scene_id = entry["scene_id"]
            url = entry["url"]
            out_path = entry["output_path"]
            print(f"  [{scene_id}] {url}")
            try:
                page.goto(url, timeout=30000, wait_until="domcontentloaded")
                time.sleep(1.5)
                run_steps(page, entry.get("steps", []))
                page.screenshot(path=out_path, full_page=False)
                kb = os.path.getsize(out_path) // 1024
                print(f"    OK  {kb}KB -> {out_path}")
                manifest["captures"].append({"scene_id": scene_id, "path": out_path})
            except Exception as e:
                print(f"    FAILED: {e}")
                manifest["failed"].append({"scene_id": scene_id, "error": str(e)})

        context.close()
        browser.close()

    with open(MANIFEST, "w") as f:
        json.dump(manifest, f, indent=2)

    ok = len(manifest["captures"])
    fail = len(manifest["failed"])
    print(f"\n{'='*50}")
    print(f"Done: {ok} captured · {fail} failed")
    if fail:
        print("Failed:", [x["scene_id"] for x in manifest["failed"]])
    print("\nNext step: open the video in CapCut/Clipchamp,")
    print("replace placeholder slides with these screenshots,")
    print("and add your voiceover from VOICEOVER_SCRIPT.txt")

if __name__ == "__main__":
    main()
