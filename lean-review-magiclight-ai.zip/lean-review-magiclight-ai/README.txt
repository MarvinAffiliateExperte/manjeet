MAGICLIGHT AI REVIEW — LOCAL RUN PACKAGE
=========================================
Keyword: text to animation AI consistent character video generator
Product: MagicLight AI — https://magiclight.ai/videos/
Voice:   alloy (add yourself in CapCut/Clipchamp)
Slides:  17

WHAT'S IN THIS PACKAGE
-----------------------
VOICEOVER_SCRIPT.txt        — Full narration for all 17 scenes (paste into CapCut TTS)
script.json                 — Full scene definitions
capture_spec.json           — Screenshot instructions per scene
run_screenshots_only.py     — Run this to capture real magiclight.ai screenshots
screenshots/reddit/         — 4 testimonial cards (t1-t4.png)
screenshots/scene/          — Placeholder scene PNGs (replace with real ones after running script)
broll/homepage.mp4          — Placeholder homepage video (12s cream frame)
out/review.mp4              — Rendered video (with placeholder assets + espeak voice)
research.json               — Product research data
reddit_threads.json         — 4 Trustpilot testimonials

STEP 1 — GET REAL SCREENSHOTS (needs internet)
-----------------------------------------------
  pip install playwright
  playwright install chromium
  python3 run_screenshots_only.py

  This overwrites screenshots/scene/*.png with real magiclight.ai captures.

STEP 2 — BRING INTO CAPCUT / CLIPCHAMP
----------------------------------------
  Option A (quick): Import out/review.mp4, mute audio,
    replace slide images with screenshots/scene/*.png,
    add voiceover using VOICEOVER_SCRIPT.txt.

  Option B (clean build): Import slides in order,
    use screenshots/reddit/*.png for testimonial slides,
    use broll/homepage.mp4 as background on title + CTA slides,
    add CapCut's free TTS using each scene's narration from VOICEOVER_SCRIPT.txt.

SCENE ORDER (17 slides)
------------------------
  01 Title card         — bookend MP4
  02 What Is It         — magiclight.ai homepage hero
  03 Character Lock     — magiclight.ai/videos/
  04 Long-Form + Styles — 3 screenshots (tools, style gallery, features)
  05 Who It's For       — use-cases scroll
  06 Testimonial ★★★★★  — t1.png (YouTube creator)
  07 Testimonial ★★★★★  — t2.png (Parent/bedtime)
  08 Pricing            — magiclight.ai/pricing/
  09 Credit Reality     — magiclight.ai/faq/
  10 Testimonial ★☆☆☆☆  — t4.png (credit scam complaint)
  11 Support Problem    — t3.png (account reset)
  12 Pros vs Cons       — no screenshot
  13 Alternatives       — magiclight.ai comparison scroll
  14 Ideal User         — magiclight.ai/academy/
  15 Skip If            — no screenshot
  16 What's New v1.2.18 — magiclight.ai/videos/ gallery
  17 CTA                — bookend MP4

TIMING (from rendered video)
-----------------------------
  Total: 6:38  |  17 scenes  |  ~23s average per slide
